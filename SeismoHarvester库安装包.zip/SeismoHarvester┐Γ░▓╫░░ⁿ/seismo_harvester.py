#!/usr/bin/env python
# coding: utf-8
# Author: Suxiang Zhang
"""
SeismoHarvester - A flexible seismic data harvesting library
用于批量下载地震波形数据的Python库
"""

import seisbench
import seisbench.data as sbd
import seisbench.util as sbu

import obspy
from obspy import UTCDateTime
from obspy.clients.fdsn import Client
from obspy.clients.fdsn.header import FDSNException
import http.client
from pathlib import Path
from collections import defaultdict
import time
import logging
from datetime import datetime
import asyncio
import aiohttp
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from queue import Queue
import pickle
import numpy as np
from typing import Optional, Dict, List, Tuple, Union


class SeismoHarvester:
    """
    地震数据批量下载器
    
    支持从多个地震数据中心下载指定时间段的波形数据，
    具有并发优化、缓存机制、断点续传等功能。
    """
    
    # 支持的数据中心
    SUPPORTED_CLIENTS = {
        "SCEDC": "Southern California Earthquake Data Center",
        "IRIS": "Incorporated Research Institutions for Seismology", 
        "NCEDC": "Northern California Earthquake Data Center",
        "USGS": "United States Geological Survey",
        "ETH": "Swiss Seismological Service",
        "GEOFON": "GEOFON Program, GFZ Potsdam",
        "INGV": "Istituto Nazionale di Geofisica e Vulcanologia",
        "LMU": "Ludwig-Maximilians University, Munich",
        "ORFEUS": "Observatories and Research Facilities for European Seismology",
    }
    
    def __init__(self, 
                 client_name: str = "SCEDC",
                 max_workers: int = 6,
                 batch_size: int = 30,
                 cache_events: bool = True,
                 cache_waveforms: bool = True,
                 log_level: str = "INFO",
                 log_file: Optional[str] = None):
        """
        初始化地震数据下载器
        
        参数:
        ----------
        client_name : str
            数据中心名称，支持: SCEDC, IRIS, NCEDC, USGS等
        max_workers : int
            最大并发下载线程数
        batch_size : int
            批处理大小
        cache_events : bool
            是否缓存事件目录
        cache_waveforms : bool
            是否缓存波形数据
        log_level : str
            日志级别 (DEBUG, INFO, WARNING, ERROR)
        log_file : str, optional
            日志文件路径，默认为 '{client_name}_download.log'
        """
        
        # 验证客户端
        if client_name not in self.SUPPORTED_CLIENTS:
            raise ValueError(f"不支持的客户端: {client_name}. 支持的客户端: {list(self.SUPPORTED_CLIENTS.keys())}")
        
        self.client_name = client_name
        self.max_workers = max_workers
        self.batch_size = batch_size
        self.cache_events = cache_events
        self.cache_waveforms = cache_waveforms
        
        # 设置日志
        self._setup_logging(log_level, log_file)
        
        # 创建客户端池
        self.clients = [Client(client_name, timeout=120) for _ in range(max_workers)]
        self.client_queue = Queue()
        for client in self.clients:
            self.client_queue.put(client)
        
        # 统计信息
        self.stats = {
            'total_events': 0,
            'total_traces': 0,
            'successful_traces': 0,
            'failed_downloads': 0,
            'cache_hits': 0,
            'overlapping_traces': 0
        }
        
        # 缓存
        self.event_cache = {}
        self.waveform_cache = {}
        
        # 进度文件
        self.progress_file = None
        
    def _setup_logging(self, log_level: str, log_file: Optional[str]):
        """设置日志系统"""
        if log_file is None:
            log_file = f"{self.client_name.lower()}_download.log"
            
        # 创建logger
        self.logger = logging.getLogger(f"SeismoHarvester.{self.client_name}")
        self.logger.setLevel(getattr(logging, log_level.upper()))
        
        # 清除已有的handlers
        self.logger.handlers.clear()
        
        # 格式化器
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # 文件handler
        fh = logging.FileHandler(log_file)
        fh.setFormatter(formatter)
        self.logger.addHandler(fh)
        
        # 控制台handler
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)
    
    def get_client(self):
        """获取一个可用的客户端"""
        return self.client_queue.get()
    
    def return_client(self, client):
        """归还客户端"""
        self.client_queue.put(client)

    def get_event_params(self, event):
        """获取地震事件参数"""
        origin = event.preferred_origin()
        mag = event.preferred_magnitude()
        sid = str(event.resource_id)
        
        params = {
            "source_id": sid,
            "source_origin_time": str(origin.time),
            "source_origin_uncertainty_sec": origin.time_errors.get("uncertainty") or 0,
            "source_latitude_deg": origin.latitude,
            "source_latitude_uncertainty_km": origin.latitude_errors.get("uncertainty") or 0,
            "source_longitude_deg": origin.longitude,
            "source_longitude_uncertainty_km": origin.longitude_errors.get("uncertainty") or 0,
            "source_depth_km": origin.depth / 1e3 if origin.depth else 0,
            "source_depth_uncertainty_km": ((origin.depth_errors.get("uncertainty") or 0) / 1e3) if origin.depth_errors else 0,
        }
        
        if mag is not None:
            params.update({
                "source_magnitude": mag.mag,
                "source_magnitude_uncertainty": mag.mag_errors.get("uncertainty") or 0,
                "source_magnitude_type": mag.magnitude_type or "",
                "source_magnitude_author": (mag.creation_info.agency_id if mag.creation_info else "") or "",
            })
        
        return params

    def get_trace_params(self, pick):
        """获取波形记录参数"""
        return {
            "station_network_code": pick.waveform_id.network_code or "",
            "station_code": pick.waveform_id.station_code or "",
            "trace_channel": pick.waveform_id.channel_code[:2] if pick.waveform_id.channel_code else "",
            "station_location_code": pick.waveform_id.location_code or "",
        }

    def get_events_cached(self, t0, t1, client, **kwargs):
        """缓存版本的事件获取"""
        cache_key = f"{t0}_{t1}_{hash(frozenset(kwargs.items()))}"
        
        if self.cache_events and cache_key in self.event_cache:
            self.logger.info(f"使用缓存的事件目录: {t0.date} → {t1.date}")
            self.stats['cache_hits'] += 1
            return self.event_cache[cache_key]
        
        # 获取新的事件目录
        for attempt in range(1, 4):
            try:
                catalog = client.get_events(
                    starttime=t0,
                    endtime=t1,
                    includearrivals=True,
                    **kwargs
                )
                
                if self.cache_events:
                    self.event_cache[cache_key] = catalog
                
                return catalog
                
            except Exception as e:
                self.logger.warning(f"获取事件第 {attempt} 次失败: {str(e)[:100]}")
                if attempt < 3:
                    time.sleep(min(5 * attempt, 15))
        
        return obspy.core.event.Catalog()

    def process_overlapping_traces(self, stream):
        """处理重叠的波形记录"""
        if len(stream) <= 1:
            return stream
        
        # 按照台站、通道、位置码分组
        trace_groups = defaultdict(list)
        for tr in stream:
            key = (tr.stats.network, tr.stats.station, 
                   tr.stats.location, tr.stats.channel)
            trace_groups[key].append(tr)
        
        # 创建新的stream
        processed_stream = obspy.Stream()
        
        for key, traces in trace_groups.items():
            if len(traces) == 1:
                processed_stream += traces[0]
            else:
                # 多个重叠的traces，需要处理
                traces.sort(key=lambda x: x.stats.starttime)
                
                # 检查是否真的有重叠
                has_overlap = False
                for i in range(len(traces) - 1):
                    if traces[i].stats.endtime > traces[i+1].stats.starttime:
                        has_overlap = True
                        break
                
                if not has_overlap:
                    for tr in traces:
                        processed_stream += tr
                else:
                    # 有重叠，尝试合并
                    try:
                        temp_stream = obspy.Stream(traces)
                        temp_stream.merge(method=1, fill_value='interpolate')
                        if len(temp_stream) > 0:
                            processed_stream += temp_stream[0]
                            self.stats['overlapping_traces'] += 1
                    except Exception as e:
                        best_trace = max(traces, key=lambda x: len(x.data))
                        processed_stream += best_trace
                        self.logger.debug(f"合并失败，选择最长的trace: {key}")
                        self.stats['overlapping_traces'] += 1
        
        return processed_stream

    def download_waveform_batch(self, waveform_requests):
        """批量下载波形数据"""
        client = self.get_client()
        results = []
        
        try:
            for req in waveform_requests:
                try:
                    net, sta, loc, ch_pref, start_wf, end_wf = req['params']
                    
                    # 检查缓存
                    cache_key = f"{net}_{sta}_{loc}_{ch_pref}_{start_wf}_{end_wf}"
                    if self.cache_waveforms and cache_key in self.waveform_cache:
                        results.append({
                            'success': True,
                            'stream': self.waveform_cache[cache_key],
                            'request': req
                        })
                        continue
                    
                    # 下载波形
                    st = client.get_waveforms(
                        network=net,
                        station=sta,
                        location=loc or "*",
                        channel=f"{ch_pref}*",
                        starttime=start_wf,
                        endtime=end_wf
                    )
                    
                    # 处理重叠的traces
                    st = self.process_overlapping_traces(st)
                    
                    # 缓存
                    if self.cache_waveforms and len(self.waveform_cache) < 1000:
                        self.waveform_cache[cache_key] = st
                    
                    results.append({
                        'success': True,
                        'stream': st,
                        'request': req
                    })
                    
                except Exception as e:
                    self.logger.debug(f"下载失败 {req['params'][:4]}: {str(e)[:50]}")
                    results.append({
                        'success': False,
                        'error': str(e),
                        'request': req
                    })
                    self.stats['failed_downloads'] += 1
                    
        finally:
            self.return_client(client)
            
        return results

    def process_event_batch(self, events, writer, data_split_func=None):
        """批量处理事件"""
        all_waveform_requests = []
        
        for event in events:
            try:
                evp = self.get_event_params(event)
                
                # 应用数据分割函数
                if data_split_func:
                    evp["split"] = data_split_func(event)
                
                # 按台站+通道分组
                station_groups = defaultdict(list)
                for pick in event.picks:
                    if not pick.waveform_id.channel_code:
                        continue
                    key = (
                        pick.waveform_id.network_code,
                        pick.waveform_id.station_code,
                        pick.waveform_id.location_code,
                        pick.waveform_id.channel_code[:2]
                    )
                    station_groups[key].append(pick)

                # 为每个台站组创建波形请求
                for (net, sta, loc, ch_pref), picks in station_groups.items():
                    start_wf = min(p.time for p in picks) - 60
                    end_wf = max(p.time for p in picks) + 60
                    
                    all_waveform_requests.append({
                        'params': (net, sta, loc, ch_pref, start_wf, end_wf),
                        'event_params': evp,
                        'picks': picks
                    })
                    
            except Exception as e:
                self.logger.warning(f"处理事件参数失败: {e}")
                continue
        
        # 并行下载波形
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            batches = [all_waveform_requests[i:i+self.batch_size] 
                      for i in range(0, len(all_waveform_requests), self.batch_size)]
            
            futures = [executor.submit(self.download_waveform_batch, batch) 
                      for batch in batches]
            
            # 处理结果
            for future in as_completed(futures):
                try:
                    batch_results = future.result()
                    
                    for result in batch_results:
                        if not result['success']:
                            continue
                            
                        req = result['request']
                        st = result['stream']
                        evp = req['event_params']
                        picks = req['picks']
                        
                        if len(st) == 0:
                            continue
                        
                        # 检查采样率
                        sr = st[0].stats.sampling_rate
                        if not all(abs(tr.stats.sampling_rate - sr) < 0.1 for tr in st):
                            continue
                        
                        try:
                            # 转换为数组
                            actual_t0, data_arr, _ = sbu.stream_to_array(
                                st,
                                component_order=writer.data_format["component_order"]
                            )
                            
                            # 处理每个pick
                            for pick in picks:
                                try:
                                    self.stats['total_traces'] += 1
                                    trp = self.get_trace_params(pick)
                                    trp["trace_sampling_rate_hz"] = sr
                                    trp["trace_start_time"] = str(actual_t0)
                                    
                                    sample = int((pick.time - actual_t0) * sr)
                                    phase = pick.phase_hint or "unknown"
                                    trp[f"trace_{phase}_arrival_sample"] = sample
                                    trp[f"trace_{phase}_status"] = pick.evaluation_mode or ""

                                    writer.add_trace({**evp, **trp}, data_arr)
                                    self.stats['successful_traces'] += 1
                                    
                                except Exception as e:
                                    self.logger.debug(f"处理pick失败: {e}")
                                    continue
                                    
                        except Exception as e:
                            self.logger.debug(f"数组转换失败: {e}")
                            continue
                            
                except Exception as e:
                    self.logger.warning(f"批处理结果失败: {e}")
                    continue

    def save_progress(self, current_time):
        """保存进度信息"""
        if self.progress_file:
            with open(self.progress_file, 'w') as f:
                f.write(f"Last processed time: {current_time}\n")
                f.write(f"Client: {self.client_name}\n")
                for key, value in self.stats.items():
                    f.write(f"{key}: {value}\n")
                if self.stats['total_traces'] > 0:
                    success_rate = self.stats['successful_traces']/self.stats['total_traces']*100
                    f.write(f"Success rate: {success_rate:.1f}%\n")

    def load_progress(self):
        """加载上次的进度"""
        if self.progress_file and Path(self.progress_file).exists():
            try:
                with open(self.progress_file, 'r') as f:
                    lines = f.readlines()
                    if lines:
                        time_str = lines[0].split(": ")[1].strip()
                        return UTCDateTime(time_str)
            except:
                pass
        return None
    
    def download(self,
                 start_time: Union[str, UTCDateTime],
                 end_time: Union[str, UTCDateTime],
                 output_dir: Union[str, Path] = "./seismic_data",
                 output_name: Optional[str] = None,
                 time_window_days: int = 3,
                 min_magnitude: float = 1.0,
                 max_magnitude: Optional[float] = None,
                 min_depth: Optional[float] = None,
                 max_depth: Optional[float] = None,
                 latitude_range: Optional[Tuple[float, float]] = None,
                 longitude_range: Optional[Tuple[float, float]] = None,
                 event_type: Optional[str] = None,
                 network: Optional[str] = None,
                 station: Optional[str] = None,
                 channel: Optional[str] = None,
                 location: Optional[str] = None,
                 data_format: Optional[Dict] = None,
                 data_split_func: Optional[callable] = None,
                 resume: bool = True):
        """
        下载指定时间段的地震数据
        
        参数:
        ----------
        start_time : str or UTCDateTime
            开始时间，如 "2024-01-01" 或 UTCDateTime对象
        end_time : str or UTCDateTime
            结束时间
        output_dir : str or Path
            输出目录
        output_name : str, optional
            输出文件名前缀，默认为 "{client_name}_{start}_{end}"
        time_window_days : int
            时间窗口大小（天）
        min_magnitude : float
            最小震级
        max_magnitude : float, optional
            最大震级
        min_depth : float, optional
            最小深度（km）
        max_depth : float, optional
            最大深度（km）
        latitude_range : tuple, optional
            纬度范围 (min_lat, max_lat)
        longitude_range : tuple, optional
            经度范围 (min_lon, max_lon)
        event_type : str, optional
            事件类型筛选
        network : str, optional
            台网代码筛选
        station : str, optional
            台站代码筛选
        channel : str, optional
            通道代码筛选
        location : str, optional
            位置代码筛选
        data_format : dict, optional
            数据格式配置
        data_split_func : callable, optional
            数据分割函数，用于划分训练/测试集
        resume : bool
            是否从上次进度继续
            
        返回:
        -------
        dict : 包含下载统计信息的字典
        """
        
        # 转换时间
        if isinstance(start_time, str):
            start_time = UTCDateTime(start_time)
        if isinstance(end_time, str):
            end_time = UTCDateTime(end_time)
            
        # 设置输出路径
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True, parents=True)
        
        # 设置输出文件名
        if output_name is None:
            output_name = f"{self.client_name}_{start_time.strftime('%Y%m%d')}_{end_time.strftime('%Y%m%d')}"
        
        # 进度文件
        self.progress_file = output_dir / f"{output_name}_progress.txt"
        
        # 输出文件路径
        metadata_path = output_dir / f"metadata-{output_name}.csv"
        waveforms_path = output_dir / f"waveforms-{output_name}.hdf5"
        
        # 设置默认数据格式
        if data_format is None:
            data_format = {
                "dimension_order": "CW",
                "component_order": "ZNE",
                "measurement": "velocity",
                "unit": "counts",
                "instrument_response": "not restituted",
            }
        
        # 准备事件查询参数
        event_kwargs = {
            "minmagnitude": min_magnitude,
        }
        if max_magnitude:
            event_kwargs["maxmagnitude"] = max_magnitude
        if min_depth:
            event_kwargs["mindepth"] = min_depth
        if max_depth:
            event_kwargs["maxdepth"] = max_depth
        if latitude_range:
            event_kwargs["minlatitude"] = latitude_range[0]
            event_kwargs["maxlatitude"] = latitude_range[1]
        if longitude_range:
            event_kwargs["minlongitude"] = longitude_range[0]
            event_kwargs["maxlongitude"] = longitude_range[1]
        if event_type:
            event_kwargs["eventtype"] = event_type
            
        # 时间窗口
        period = time_window_days * 24 * 3600
        
        # 检查是否恢复
        if resume:
            last_processed = self.load_progress()
            if last_processed:
                start_time = last_processed
                self.logger.info(f"从上次进度继续: {start_time}")
        
        self.logger.info(f"开始下载 {self.client_name} 数据")
        self.logger.info(f"时间范围: {start_time} → {end_time}")
        self.logger.info(f"查询参数: {event_kwargs}")
        
        try:
            with sbd.WaveformDataWriter(metadata_path, waveforms_path) as writer:
                writer.data_format = data_format

                t0 = start_time
                window_count = 0
                
                while t0 < end_time:
                    t1 = min(t0 + period, end_time)
                    window_count += 1
                    self.logger.info(f"处理时间窗口 {window_count}: {t0.date} → {t1.date}")

                    # 获取事件目录
                    client = self.get_client()
                    try:
                        catalog = self.get_events_cached(t0, t1, client, **event_kwargs)
                        self.logger.info(f"获取到 {len(catalog)} 个事件")
                        self.stats['total_events'] += len(catalog)
                    finally:
                        self.return_client(client)

                    if len(catalog) == 0:
                        t0 = t1
                        continue

                    # 应用台站筛选
                    if network or station:
                        # 这里可以添加基于pick的筛选逻辑
                        pass

                    # 分批处理事件
                    event_batches = [catalog[i:i+self.batch_size] 
                                   for i in range(0, len(catalog), self.batch_size)]
                    
                    for batch_idx, event_batch in enumerate(event_batches):
                        self.logger.info(f"处理事件批次 {batch_idx + 1}/{len(event_batches)}")
                        self.process_event_batch(event_batch, writer, data_split_func)
                    
                    # 保存进度
                    self.save_progress(t1)
                    
                    # 输出统计信息
                    if self.stats['total_traces'] > 0:
                        success_rate = self.stats['successful_traces'] / self.stats['total_traces'] * 100
                        self.logger.info(
                            f"当前统计: 事件 {self.stats['total_events']}, "
                            f"波形 {self.stats['successful_traces']}/{self.stats['total_traces']} "
                            f"({success_rate:.1f}%)"
                        )
                    
                    # 移动到下一个窗口
                    t0 = t1
                    
                    # 清理缓存
                    if len(self.waveform_cache) > 2000:
                        self.waveform_cache.clear()
                        self.logger.info("清理波形缓存")

        except KeyboardInterrupt:
            self.logger.info("用户中断，保存当前进度...")
            self.save_progress(t0)
            raise
        except Exception as e:
            self.logger.error(f"程序异常终止: {e}")
            self.save_progress(t0)
            raise

        # 最终统计
        self.logger.info("=" * 50)
        self.logger.info("下载完成！")
        self.logger.info(f"数据保存在: {output_dir.absolute()}")
        self.logger.info("=" * 50)
        
        # 返回统计信息
        final_stats = self.stats.copy()
        if self.stats['total_traces'] > 0:
            final_stats['success_rate'] = self.stats['successful_traces'] / self.stats['total_traces'] * 100
        
        return final_stats
    
    def get_stats(self) -> Dict:
        """获取当前统计信息"""
        stats = self.stats.copy()
        if self.stats['total_traces'] > 0:
            stats['success_rate'] = self.stats['successful_traces'] / self.stats['total_traces'] * 100
        return stats
    
    def clear_cache(self):
        """清空所有缓存"""
        self.event_cache.clear()
        self.waveform_cache.clear()
        self.logger.info("已清空所有缓存")
    
    def list_supported_clients(self) -> Dict[str, str]:
        """列出所有支持的数据中心"""
        return self.SUPPORTED_CLIENTS.copy()
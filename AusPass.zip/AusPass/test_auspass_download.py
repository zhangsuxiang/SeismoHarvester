#!/usr/bin/env python
# coding: utf-8
"""
AusPass数据下载测试脚本
用于测试AusPass下载功能是否正常
"""

from auspass_seismo_harvester import AusPassSeismoHarvester
from obspy import UTCDateTime
import seisbench.data as sbd

def test_auspass_connection():
    """测试AusPass连接"""
    print("="*60)
    print("测试AusPass数据中心连接")
    print("="*60)
    
    try:
        from obspy.clients.fdsn import Client
        client = Client("AUSPASS", timeout=30)
        print("✓ 成功连接到AusPass数据中心")
        
        # 获取可用网络
        print("\n查询可用台网...")
        inventory = client.get_stations(level="network")
        print(f"找到 {len(inventory)} 个台网:")
        for net in inventory:
            print(f"  - {net.code}: {net.description or '无描述'}")
            
        return True
        
    except Exception as e:
        print(f"✗ 连接失败: {e}")
        return False


def test_single_day_download():
    """测试下载单天数据"""
    
    print("\n" + "="*60)
    print("AusPass单日数据下载测试")
    print("="*60)
    
    # 创建下载器
    harvester = AusPassSeismoHarvester(
        max_workers=2,  # 使用较少的线程
        batch_size=10,  # 较小的批次
        log_level="INFO"
    )
    
    # 测试参数
    test_date = "2024-03-15"  # 测试日期
    output_dir = "./auspass_test_download"
    
    print(f"\n测试配置:")
    print(f"  测试日期: {test_date}")
    print(f"  震级限制: 无")
    print(f"  输出目录: {output_dir}")
    print(f"  地理范围: 澳大利亚东部 (-35°到-25°, 145°到155°)")
    
    # 获取测试日期的事件
    day_start = UTCDateTime(f"{test_date}T00:00:00")
    day_end = UTCDateTime(f"{test_date}T23:59:59")
    
    print(f"\n获取 {test_date} 的地震事件...")
    
    client = harvester.get_client()
    try:
        # 测试澳大利亚东部地区
        catalog = client.get_events(
            starttime=day_start,
            endtime=day_end,
            minlatitude=-35,
            maxlatitude=-25,
            minlongitude=145,
            maxlongitude=155,
            orderby="time"
        )
        print(f"找到 {len(catalog)} 个地震事件")
        
        if len(catalog) > 0:
            # 显示前几个事件
            print("\n事件信息:")
            for i, event in enumerate(catalog[:5]):
                origin = event.preferred_origin()
                mag = event.preferred_magnitude()
                if mag:
                    mag_str = f"M{mag.mag:.1f}"
                else:
                    mag_str = "M?"
                print(f"  {i+1}. 时间: {origin.time}, 震级: {mag_str}, "
                      f"位置: ({origin.latitude:.2f}°, {origin.longitude:.2f}°), "
                      f"深度: {origin.depth/1000:.1f}km")
        
    except Exception as e:
        print(f"获取事件失败: {e}")
        # 如果没有事件，创建一个测试事件
        print("\n尝试获取更大范围的事件...")
        try:
            catalog = client.get_events(
                starttime=day_start,
                endtime=day_end,
                minlatitude=-45,
                maxlatitude=-10,
                minlongitude=110,
                maxlongitude=155,
                orderby="time",
                limit=5  # 只获取5个事件用于测试
            )
            print(f"在澳大利亚全境找到 {len(catalog)} 个事件")
        except:
            print("未找到事件，测试结束")
            return
    finally:
        harvester.return_client(client)
    
    if len(catalog) == 0:
        print("没有找到符合条件的事件")
        return
    
    # 测试下载第一个事件
    print("\n测试下载第一个事件的数据...")
    test_event = catalog[0]
    
    # 获取台站
    stations = harvester.get_stations_for_event(test_event, max_stations=5)
    print(f"找到 {len(stations)} 个台站")
    
    if len(stations) > 0:
        print("\n台站信息:")
        for i, station in enumerate(stations):
            print(f"  {i+1}. {station['network']}.{station['station']} "
                  f"位置: ({station['latitude']:.2f}°, {station['longitude']:.2f}°) "
                  f"距离: {station['distance_deg']:.1f}°")
    
    # 创建测试数据集
    print("\n创建测试数据集...")
    metadata_path = f"{output_dir}/test_metadata.csv"
    waveforms_path = f"{output_dir}/test_waveforms.hdf5"
    
    data_format = {
        "dimension_order": "CW",
        "component_order": "ZNE",
        "measurement": "velocity",
        "unit": "counts",
        "instrument_response": "not restituted",
    }
    
    try:
        with sbd.WaveformDataWriter(metadata_path, waveforms_path) as writer:
            writer.data_format = data_format
            
            # 下载第一个事件
            harvester.process_event_batch([test_event], writer, split='test')
            
        print("\n测试完成！")
        print(f"成功下载: {harvester.stats['successful_downloads']} 个波形")
        print(f"失败下载: {harvester.stats['failed_downloads']} 个波形")
        
        # 读取并显示数据集信息
        if harvester.stats['successful_downloads'] > 0:
            print("\n读取数据集信息...")
            dataset = sbd.WaveformDataset(metadata_path, waveforms_path)
            print(f"数据集包含 {len(dataset)} 条记录")
            
            if len(dataset) > 0:
                # 显示第一条记录的信息
                metadata, waveform = dataset[0]
                print("\n第一条记录信息:")
                print(f"  台站: {metadata['station_network_code']}.{metadata['station_code']}")
                print(f"  震中距: {metadata['station_epicentral_distance_deg']:.1f}°")
                print(f"  采样率: {metadata['trace_sampling_rate_hz']} Hz")
                print(f"  波形形状: {waveform.shape}")
                
    except Exception as e:
        print(f"\n测试过程中发生错误: {e}")
        import traceback
        traceback.print_exc()


def test_station_coverage():
    """测试澳大利亚地区的台站覆盖"""
    
    print("\n" + "="*60)
    print("测试澳大利亚台站覆盖")
    print("="*60)
    
    harvester = AusPassSeismoHarvester(max_workers=1)
    client = harvester.get_client()
    
    # 测试几个主要城市附近的台站
    test_locations = {
        "Sydney": (-33.87, 151.21),
        "Melbourne": (-37.81, 144.96),
        "Brisbane": (-27.47, 153.03),
        "Perth": (-31.95, 115.86),
        "Adelaide": (-34.93, 138.60),
        "Darwin": (-12.46, 130.84)
    }
    
    print("\n主要城市附近的台站数量（半径100km内）:")
    print("-" * 50)
    
    for city, (lat, lon) in test_locations.items():
        try:
            inventory = client.get_stations(
                latitude=lat,
                longitude=lon,
                maxradius=1.0,  # 约100km
                level="station",
                channel="?H?",
                starttime=UTCDateTime() - 86400,
                endtime=UTCDateTime()
            )
            
            station_count = sum(len(net) for net in inventory)
            print(f"{city:15} | {station_count:3d} 个台站")
            
        except Exception as e:
            print(f"{city:15} | 查询失败: {str(e)[:30]}")
    
    harvester.return_client(client)


def test_data_availability():
    """测试不同时间段的数据可用性"""
    
    print("\n" + "="*60)
    print("测试数据可用性")
    print("="*60)
    
    harvester = AusPassSeismoHarvester(max_workers=1)
    client = harvester.get_client()
    
    # 测试最近几个月的数据
    test_dates = [
        "2024-01-15",
        "2024-02-15",
        "2024-03-15",
        "2024-04-15",
        "2024-05-15",
        "2024-06-15"
    ]
    
    print("\n各月份事件数量（澳大利亚全境）:")
    print("-" * 50)
    
    for date_str in test_dates:
        try:
            day_start = UTCDateTime(f"{date_str}T00:00:00")
            day_end = UTCDateTime(f"{date_str}T23:59:59")
            
            catalog = client.get_events(
                starttime=day_start,
                endtime=day_end,
                minlatitude=-45,
                maxlatitude=-10,
                minlongitude=110,
                maxlongitude=155
            )
            
            print(f"{date_str} | {len(catalog):3d} 个事件")
            
        except Exception as e:
            print(f"{date_str} | 查询失败: {str(e)[:30]}")
    
    harvester.return_client(client)


if __name__ == "__main__":
    print("AusPass数据下载功能测试\n")
    
    # 1. 测试连接
    if not test_auspass_connection():
        print("\n无法连接到AusPass，请检查网络连接")
        sys.exit(1)
    
    # 2. 测试台站覆盖
    test_station_coverage()
    
    # 3. 测试数据可用性
    test_data_availability()
    
    # 4. 测试实际下载
    user_input = input("\n是否进行实际下载测试？(y/n): ")
    if user_input.lower() == 'y':
        test_single_day_download()
    
    print("\n测试完成！")
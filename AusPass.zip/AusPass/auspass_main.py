#!/usr/bin/env python
# coding: utf-8
"""
AusPass地震数据下载脚本
下载AusPass数据中心的地震波形数据
不限制震级，不进行质量控制
"""

from auspass_seismo_harvester import AusPassSeismoHarvester
from pathlib import Path
import sys

def download_auspass_data(year=2024, resume_from_day=None):
    """
    下载AusPass地震数据的主函数
    
    参数:
    ----------
    year : int
        下载的年份
    resume_from_day : int, optional
        从第几天开始下载（1-366），用于断点续传
    """
    
    print("="*60)
    print(f"AusPass {year}年地震数据下载程序")
    print("="*60)
    
    # 配置参数
    # ========== 可根据需要修改以下参数 ==========
    
    # 输出目录
    output_dir = f"./auspass_{year}_dataset"
    
    # 震级范围
    min_magnitude = None  # 不限制最小震级
    max_magnitude = None  # 不限制最大震级
    
    # 地理范围（默认澳大利亚地区）
    # 澳大利亚本土
    latitude_range = (-45, -10)
    longitude_range = (110, 155)
    
    # 如需下载特定区域，可修改范围
    # 示例1：东澳大利亚（包括新南威尔士州、维多利亚州、昆士兰州）
    # latitude_range = (-40, -10)
    # longitude_range = (140, 155)
    
    # 示例2：西澳大利亚
    # latitude_range = (-35, -15)
    # longitude_range = (110, 130)
    
    # 示例3：塔斯马尼亚
    # latitude_range = (-44, -40)
    # longitude_range = (144, 149)
    
    # 数据集分割
    split_ratio = 0.0  # 0%训练集，100%验证集
    
    # 下载器配置
    max_workers = 6  # 并发线程数
    batch_size = 30  # 批处理大小
    
    # ========== 配置结束 ==========
    
    # 创建下载器实例
    print("\n初始化下载器...")
    harvester = AusPassSeismoHarvester(
        max_workers=max_workers,
        batch_size=batch_size,
        cache_inventory=True,  # 缓存台站信息
        cache_waveforms=True,  # 缓存波形数据
        log_level="INFO"
    )
    
    # 显示下载配置
    print(f"\n下载配置:")
    print(f"  年份: {year}")
    print(f"  输出目录: {Path(output_dir).absolute()}")
    print(f"  震级范围: 不限制")
    print(f"  地理范围: 纬度 {latitude_range}, 经度 {longitude_range}")
    print(f"  数据分割: {int(split_ratio*100)}% 训练集, {int((1-split_ratio)*100)}% 验证集")
    print(f"  并发线程: {max_workers}")
    if resume_from_day:
        print(f"  断点续传: 从第 {resume_from_day} 天开始")
    
    # 开始下载
    print("\n开始下载...")
    print("提示：")
    print("  - 程序按天下载，支持断点续传")
    print("  - 不限制震级，将下载所有可用事件")
    print("  - 不进行质量控制，保留原始数据")
    print("  - 如果中断，程序会自动记录进度")
    
    try:
        stats = harvester.download_year_data(
            year=year,
            output_dir=output_dir,
            min_magnitude=min_magnitude,
            max_magnitude=max_magnitude,
            latitude_range=latitude_range,
            longitude_range=longitude_range,
            split_ratio=split_ratio,
            resume_from_day=resume_from_day
        )
        
        # 显示最终统计
        print("\n" + "="*60)
        print("下载完成！统计信息：")
        print(f"  总事件数: {stats['total_events']}")
        print(f"  成功下载: {stats['successful_downloads']}")
        print(f"  数据总量: {stats['data_volume_gb']:.2f} GB")
        print("="*60)
        
    except KeyboardInterrupt:
        print("\n\n用户中断下载")
        print("提示：程序支持断点续传，下次运行会从中断处继续")
        print(f"使用方法：python auspass_main.py {year} [起始天数]")
    except Exception as e:
        print(f"\n\n下载过程中发生错误: {e}")
        print("请检查网络连接和日志文件")


def download_specific_regions():
    """下载澳大利亚特定区域的示例函数"""
    
    # 示例1：下载新南威尔士州地区数据
    print("下载新南威尔士州地区数据...")
    harvester_nsw = AusPassSeismoHarvester(max_workers=8)
    
    stats_nsw = harvester_nsw.download_year_data(
        year=2024,
        output_dir="./auspass_2024_nsw",
        min_magnitude=None,  # 不限制震级
        latitude_range=(-38, -28),
        longitude_range=(140, 154),
        split_ratio=0.8
    )
    
    # 示例2：下载多个州的数据
    print("\n下载澳大利亚各州数据...")
    harvester_states = AusPassSeismoHarvester(max_workers=10)
    
    # 各州大致范围
    states = {
        "queensland": {"lat": (-29, -10), "lon": (138, 154)},
        "victoria": {"lat": (-39, -34), "lon": (141, 150)},
        "western_australia": {"lat": (-35, -13), "lon": (112, 129)},
        "south_australia": {"lat": (-38, -26), "lon": (129, 141)},
        "tasmania": {"lat": (-44, -40), "lon": (144, 149)},
        "northern_territory": {"lat": (-26, -11), "lon": (129, 138)}
    }
    
    for state_name, coords in states.items():
        print(f"\n下载 {state_name} 地区...")
        stats = harvester_states.download_year_data(
            year=2024,
            output_dir=f"./auspass_2024_{state_name}",
            min_magnitude=None,
            latitude_range=coords["lat"],
            longitude_range=coords["lon"],
            split_ratio=0.8
        )


def download_mining_regions():
    """下载矿区地震活动数据的示例"""
    
    print("下载澳大利亚主要矿区地震数据...")
    
    harvester = AusPassSeismoHarvester(
        max_workers=8,
        batch_size=50,
        cache_waveforms=True
    )
    
    # 主要矿区范围
    mining_regions = {
        "pilbara": {  # 西澳皮尔巴拉铁矿区
            "lat": (-24, -20),
            "lon": (115, 120)
        },
        "goldfields": {  # 西澳金矿区
            "lat": (-32, -28),
            "lon": (119, 123)
        },
        "hunter_valley": {  # 新南威尔士猎人谷煤矿区
            "lat": (-33, -31),
            "lon": (150, 152)
        },
        "bowen_basin": {  # 昆士兰博文盆地煤矿区
            "lat": (-25, -20),
            "lon": (147, 150)
        }
    }
    
    for region_name, coords in mining_regions.items():
        print(f"\n下载 {region_name} 矿区数据...")
        stats = harvester.download_year_data(
            year=2024,
            output_dir=f"./auspass_2024_mining_{region_name}",
            min_magnitude=None,  # 包括微震
            latitude_range=coords["lat"],
            longitude_range=coords["lon"],
            split_ratio=0.9  # 90%训练集，因为矿区地震较多
        )


def print_usage():
    """打印使用说明"""
    print("\n使用方法:")
    print("  python auspass_main.py              # 下载2024年数据")
    print("  python auspass_main.py [年份]       # 下载指定年份数据")
    print("  python auspass_main.py [年份] [天数] # 从指定天数开始（断点续传）")
    print("\n示例:")
    print("  python auspass_main.py 2023         # 下载2023年数据")
    print("  python auspass_main.py 2024 45      # 从2024年第45天开始下载")
    print("\n注意:")
    print("  - 程序会自动保存进度")
    print("  - 中断后可以随时继续下载")
    print("  - 不限制震级，会下载所有可用地震事件")


if __name__ == "__main__":
    # 默认年份
    year = 2024
    resume_day = None
    
    # 解析命令行参数
    if len(sys.argv) > 1:
        if sys.argv[1] in ['-h', '--help']:
            print_usage()
            sys.exit(0)
        try:
            year = int(sys.argv[1])
            if year < 2000 or year > 2030:
                print(f"错误：年份必须在2000-2030之间，您输入的是 {year}")
                sys.exit(1)
        except ValueError:
            print("错误：无效的年份参数")
            print_usage()
            sys.exit(1)
            
    if len(sys.argv) > 2:
        try:
            resume_day = int(sys.argv[2])
            total_days = 366 if year % 4 == 0 else 365
            if resume_day < 1 or resume_day > total_days:
                print(f"错误：天数必须在1-{total_days}之间，您输入的是 {resume_day}")
                sys.exit(1)
            print(f"断点续传模式：从{year}年第 {resume_day} 天开始")
        except ValueError:
            print("警告：无效的天数参数，从头开始下载")
    
    # 运行主下载函数
    download_auspass_data(year=year, resume_from_day=resume_day)
    
    # 如果需要下载特定区域，取消下面的注释
    # download_specific_regions()
    
    # 如果需要下载矿区数据，取消下面的注释
    # download_mining_regions()
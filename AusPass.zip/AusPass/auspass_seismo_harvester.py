#!/usr/bin/env python
# coding: utf-8
# Author: Modified for AusPass data download
"""
AusPass SeismoHarvester - 专门用于下载AusPass地震数据的版本
不限制震级，不进行质量控制，专注于波形下载
"""

import numpy as np
import obspy
from obspy import UTCDateTime
from obspy.clients.fdsn import Client
from obspy.geodetics import gps2dist_azimuth, kilometers2degrees
from obspy.taup import TauPyModel
import pandas as pd
from pathlib import Path
from collections import defaultdict
import time
import logging
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue
import json
from typing import Optional, Dict, List, Tuple, Union
import seisbench
import seisbench.data as sbd
import seisbench.util as sbu


class AusPassSeismoHarvester:
    """
    AusPass地震数据批量下载器
    
    专门为AusPass数据中心优化，不限制震级，
    不进行质量控制，使用理论到时计算。
    """
    
    def __init__(self, 
                 max_workers: int = 8,
                 batch_size: int = 50,
                 cache_inventory: bool = True,
                 cache_waveforms: bool = True,
                 log_level: str = "INFO",
                 log_file: Optional[str] = None,
                 velocity_model: str = "iasp91"):
        """
        初始化AusPass数据下载器
        
        参数:
        ----------
        max_workers : int
            最大并发下载线程数
        batch_size : int
            批处理大小
        cache_inventory : bool
            是否缓存台站信息
        cache_waveforms : bool
            是否缓存波形数据
        log_level : str
            日志级别
        log_file : str, optional
            日志文件路径
        velocity_model : str
            速度模型，可选: iasp91, prem, ak135
        """
        
        self.client_name = "AUSPASS"
        self.max_workers = max_workers
        self.batch_size = batch_size
        self.cache_inventory = cache_inventory
        self.cache_waveforms = cache_waveforms
        self.velocity_model = velocity_model
        
        # 设置日志
        self._setup_logging(log_level, log_file)
        
        # 创建客户端池
        self.clients = [Client("AUSPASS", timeout=180) for _ in range(max_workers)]
        self.client_queue = Queue()
        for client in self.clients:
            self.client_queue.put(client)
        
        # TauP模型用于计算理论到时
        self.taup_model = TauPyModel(model=velocity_model)
        
        # 统计信息
        self.stats = {
            'total_events': 0,
            'total_stations': 0,
            'total_downloads': 0,
            'successful_downloads': 0,
            'failed_downloads': 0,
            'cache_hits': 0,
            'data_volume_gb': 0,
            'daily_events': {}  # 每日事件统计
        }
        
        # 缓存
        self.inventory_cache = {}
        self.waveform_cache = {}
        self.station_coords_cache = {}
        
        # 进度文件
        self.progress_file = None
        
    def _setup_logging(self, log_level: str, log_file: Optional[str]):
        """设置日志系统"""
        if log_file is None:
            log_file = f"auspass_download_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
            
        self.logger = logging.getLogger("AusPassSeismoHarvester")
        self.logger.setLevel(getattr(logging, log_level.upper()))
        self.logger.handlers.clear()
        
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # 文件handler
        fh = logging.FileHandler(log_file)
        fh.setFormatter(formatter)
        self.logger.addHandler(fh)
        
        # 控制台handler
        ch = logging.StreamHandler()
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)
    
    def get_client(self):
        """获取一个可用的客户端"""
        return self.client_queue.get()
    
    def return_client(self, client):
        """归还客户端"""
        self.client_queue.put(client)
    
    def calculate_travel_times(self, source_depth_km, distance_deg, phases=None):
        """
        计算理论到时
        
        参数:
        ----------
        source_depth_km : float
            震源深度（km）
        distance_deg : float
            震中距（度）
        phases : list, optional
            要计算的震相列表
            
        返回:
        -------
        dict : 包含各震相到时的字典
        """
        try:
            # 限制深度范围
            source_depth_km = max(0, min(source_depth_km, 700))
            
            # 根据深度和距离选择合适的震相
            if phases is None:
                if source_depth_km < 50:  # 浅震
                    if distance_deg < 10:
                        phases = ['P', 'p', 'S', 's', 'Pg', 'Sg', 'Pn', 'Sn']
                    elif distance_deg < 30:
                        phases = ['P', 'p', 'S', 's', 'Pn', 'Sn', 'PmP', 'SmS']
                    else:
                        phases = ['P', 'p', 'S', 's', 'PP', 'SS']
                elif source_depth_km < 300:  # 中源地震
                    phases = ['P', 'p', 'S', 's', 'pP', 'sP', 'pS', 'sS']
                else:  # 深震
                    phases = ['P', 'p', 'S', 's', 'pP', 'sP', 'pS', 'sS', 'PP', 'SS']
            
            # 计算到时
            arrivals = self.taup_model.get_travel_times(
                source_depth_km=source_depth_km,
                distance_in_degree=distance_deg,
                phase_list=phases
            )
            
            travel_times = {}
            
            # 优先级：直达波 > 其他震相
            priority_phases = {
                'P': ['P', 'p', 'Pn', 'Pg', 'pP', 'sP'],
                'S': ['S', 's', 'Sn', 'Sg', 'sS', 'pS']
            }
            
            for main_phase in ['P', 'S']:
                for arrival in arrivals:
                    if arrival.name in priority_phases[main_phase] and main_phase not in travel_times:
                        travel_times[main_phase] = arrival.time
                        travel_times[f'{main_phase}_phase'] = arrival.name
                        break
            
            # 如果没有找到S波，使用经验公式估算
            if 'S' not in travel_times and 'P' in travel_times:
                # Vp/Vs比值
                vp_vs_ratio = 1.73
                travel_times['S'] = travel_times['P'] * vp_vs_ratio
                travel_times['S_phase'] = 'estimated'
            
            return travel_times
            
        except Exception as e:
            self.logger.debug(f"计算理论到时失败: {e}")
            # 使用简化的经验公式
            p_time = distance_deg * 8.0 + source_depth_km * 0.1
            s_time = p_time * 1.73
            return {'P': p_time, 'S': s_time, 'P_phase': 'empirical', 'S_phase': 'empirical'}
    
    def get_time_window(self, event, station_lat, station_lon, pre_arrival=60, post_arrival=180):
        """
        计算下载时间窗口（简化版，固定时间窗口）
        
        参数:
        ----------
        event : obspy.core.event.Event
            地震事件
        station_lat : float
            台站纬度
        station_lon : float
            台站经度
        pre_arrival : float
            P波到达前的时间（秒）
        post_arrival : float
            S波到达后的时间（秒）
            
        返回:
        -------
        tuple : (开始时间, 结束时间, 震中距)
        """
        origin = event.preferred_origin()
        
        # 计算震中距
        distance_m, _, _ = gps2dist_azimuth(
            origin.latitude, origin.longitude,
            station_lat, station_lon
        )
        distance_deg = kilometers2degrees(distance_m / 1000.0)
        
        # 不限制距离，下载所有可用数据
        
        # 计算理论到时
        depth_km = origin.depth / 1000.0 if origin.depth else 10.0
        travel_times = self.calculate_travel_times(depth_km, distance_deg)
        
        if travel_times['P'] is None:
            return None, None, distance_deg
        
        # 计算时间窗口
        origin_time = origin.time
        p_arrival = origin_time + travel_times['P']
        s_arrival = origin_time + travel_times['S'] if travel_times['S'] else p_arrival + travel_times['P'] * 0.73
        
        start_time = p_arrival - pre_arrival
        end_time = s_arrival + post_arrival
        
        # 固定最大时间窗口为10分钟
        max_window = 600
        if (end_time - start_time) > max_window:
            end_time = start_time + max_window
        
        return start_time, end_time, distance_deg
    
    def get_stations_for_event(self, event, max_radius_deg=None, min_stations=5, max_stations=50):
        """
        获取事件周围的台站 - AusPass版本
        
        参数:
        ----------
        event : obspy.core.event.Event
            地震事件
        max_radius_deg : float
            最大搜索半径（度）
        min_stations : int
            最少台站数
        max_stations : int
            最多台站数
            
        返回:
        -------
        list : 台站信息列表
        """
        origin = event.preferred_origin()
        mag = event.preferred_magnitude()
        
        # AusPass主要覆盖澳大利亚地区，使用适合的搜索半径
        # 不限制震级，使用统一的搜索策略
        if mag and mag.mag:
            magnitude = mag.mag
        else:
            magnitude = 0.0  # 如果没有震级信息，假设为0
        
        # 澳大利亚地区的搜索策略
        # 考虑到澳大利亚地域广阔但台站分布不均
        if magnitude >= 5.0:
            search_radius = 30.0
            fallback_radius = 50.0
        elif magnitude >= 3.0:
            search_radius = 20.0
            fallback_radius = 35.0
        elif magnitude >= 1.0:
            search_radius = 15.0
            fallback_radius = 25.0
        else:  # 微震或无震级信息
            search_radius = 10.0
            fallback_radius = 20.0
        
        # 如果指定了最大半径，使用较大值
        if max_radius_deg:
            search_radius = max(search_radius, max_radius_deg)
            
        # 获取台站清单
        client = self.get_client()
        stations = []
        attempt = 0
        
        try:
            while len(stations) < min_stations and attempt < 3:
                # 尝试从缓存获取
                cache_key = f"{origin.latitude:.2f}_{origin.longitude:.2f}_{search_radius:.1f}"
                
                if self.cache_inventory and cache_key in self.inventory_cache:
                    inventory = self.inventory_cache[cache_key]
                else:
                    try:
                        inventory = client.get_stations(
                            latitude=origin.latitude,
                            longitude=origin.longitude,
                            maxradius=search_radius,
                            level="channel",
                            channel="?H?",  # 高采样率地震计
                            starttime=origin.time - 86400,
                            endtime=origin.time + 86400
                        )
                        
                        if self.cache_inventory:
                            self.inventory_cache[cache_key] = inventory
                            
                    except Exception as e:
                        if "No data" in str(e) and attempt < 2:
                            # 扩大搜索范围
                            self.logger.info(f"在 {search_radius} 度内未找到台站，扩大搜索范围...")
                            search_radius = min(search_radius * 1.5, fallback_radius)
                            attempt += 1
                            continue
                        else:
                            raise e
                
                # 提取台站信息
                stations = []
                for network in inventory:
                    for station in network:
                        # 计算震中距
                        distance_m, _, _ = gps2dist_azimuth(
                            origin.latitude, origin.longitude,
                            station.latitude, station.longitude
                        )
                        distance_deg = kilometers2degrees(distance_m / 1000.0)
                        
                        # 获取可用的通道
                        channels = []
                        for channel in station:
                            if channel.code[2] in ['Z', 'N', 'E', '1', '2']:
                                channels.append(channel.code[:2])
                        
                        if channels:
                            channel_prefix = max(set(channels), key=channels.count)
                            
                            stations.append({
                                'network': network.code,
                                'station': station.code,
                                'location': station[0].location_code if station[0].location_code else "",
                                'channel_prefix': channel_prefix,
                                'latitude': station.latitude,
                                'longitude': station.longitude,
                                'distance_deg': distance_deg
                            })
                
                # 如果台站数量不足，继续扩大搜索范围
                if len(stations) < min_stations and attempt < 2:
                    self.logger.info(f"找到 {len(stations)} 个台站，继续扩大搜索...")
                    search_radius = min(search_radius * 1.5, fallback_radius)
                    attempt += 1
                else:
                    break
                    
        except Exception as e:
            self.logger.warning(f"获取台站信息失败: {e}")
            return []
        finally:
            self.return_client(client)
        
        # 按距离排序
        stations.sort(key=lambda x: x['distance_deg'])
        
        # 选择台站（不超过最大数量）
        if len(stations) > max_stations:
            # 确保有近中远台的分布
            near_stations = [s for s in stations if s['distance_deg'] < 5.0]
            mid_stations = [s for s in stations if 5.0 <= s['distance_deg'] < 15.0]
            far_stations = [s for s in stations if s['distance_deg'] >= 15.0]
            
            # 按比例选择
            n_near = min(len(near_stations), max_stations // 3)
            n_mid = min(len(mid_stations), max_stations // 3)
            n_far = min(len(far_stations), max_stations - n_near - n_mid)
            
            stations = near_stations[:n_near] + mid_stations[:n_mid] + far_stations[:n_far]
            
        return stations
    
    def download_waveform_batch(self, requests):
        """批量下载波形数据（无质量控制）"""
        client = self.get_client()
        results = []
        
        try:
            for req in requests:
                try:
                    # 检查缓存
                    cache_key = f"{req['network']}_{req['station']}_{req['location']}_{req['channel_prefix']}_{req['start_time']}_{req['end_time']}"
                    
                    if self.cache_waveforms and cache_key in self.waveform_cache:
                        results.append({
                            'success': True,
                            'stream': self.waveform_cache[cache_key],
                            'request': req
                        })
                        self.stats['cache_hits'] += 1
                        continue
                    
                    # 下载波形
                    st = client.get_waveforms(
                        network=req['network'],
                        station=req['station'],
                        location=req['location'] or "*",
                        channel=f"{req['channel_prefix']}*",
                        starttime=req['start_time'],
                        endtime=req['end_time']
                    )
                    
                    # 不进行质量控制，直接使用原始数据
                    if len(st) > 0:
                        # 基本的合并处理
                        try:
                            st = st.merge(method=1, fill_value='interpolate')
                        except Exception:
                            pass  # 如果合并失败，使用原始数据
                        
                        # 缓存
                        if self.cache_waveforms and len(self.waveform_cache) < 2000:
                            self.waveform_cache[cache_key] = st
                            
                        results.append({
                            'success': True,
                            'stream': st,
                            'request': req
                        })
                        
                        # 统计数据量
                        for tr in st:
                            data_size_gb = tr.data.nbytes / (1024**3)
                            self.stats['data_volume_gb'] += data_size_gb
                    else:
                        results.append({
                            'success': False,
                            'error': 'Empty stream',
                            'request': req
                        })
                        
                except Exception as e:
                    self.logger.debug(f"下载失败 {req['network']}.{req['station']}: {str(e)[:50]}")
                    results.append({
                        'success': False,
                        'error': str(e),
                        'request': req
                    })
                    self.stats['failed_downloads'] += 1
                    
        finally:
            self.return_client(client)
            
        return results
    
    def process_event_batch(self, events, writer, split='train'):
        """处理事件批次"""
        all_requests = []
        
        for event in events:
            try:
                # 获取事件参数
                origin = event.preferred_origin()
                mag = event.preferred_magnitude()
                
                if not origin:
                    continue
                    
                event_params = {
                    "source_id": str(event.resource_id),
                    "source_origin_time": str(origin.time),
                    "source_origin_uncertainty_sec": origin.time_errors.get("uncertainty", 0) or 0,
                    "source_latitude_deg": origin.latitude,
                    "source_latitude_uncertainty_km": origin.latitude_errors.get("uncertainty", 0) or 0,
                    "source_longitude_deg": origin.longitude,
                    "source_longitude_uncertainty_km": origin.longitude_errors.get("uncertainty", 0) or 0,
                    "source_depth_km": origin.depth / 1e3 if origin.depth else 10.0,
                    "source_depth_uncertainty_km": ((origin.depth_errors.get("uncertainty", 0) or 0) / 1e3) if origin.depth_errors else 0,
                    "split": split
                }
                
                if mag:
                    event_params.update({
                        "source_magnitude": mag.mag,
                        "source_magnitude_uncertainty": mag.mag_errors.get("uncertainty", 0) or 0,
                        "source_magnitude_type": mag.magnitude_type or "ML",
                        "source_magnitude_author": (mag.creation_info.agency_id if mag.creation_info else "AUSPASS") or "AUSPASS",
                    })
                else:
                    # 如果没有震级信息，设置为-999
                    event_params.update({
                        "source_magnitude": -999,
                        "source_magnitude_uncertainty": 0,
                        "source_magnitude_type": "unknown",
                        "source_magnitude_author": "AUSPASS",
                    })
                
                # 获取台站
                stations = self.get_stations_for_event(event)
                
                if not stations:
                    self.logger.debug(f"事件 {event.resource_id} 没有找到合适的台站")
                    continue
                    
                self.logger.info(f"事件 {event.resource_id} 找到 {len(stations)} 个台站")
                
                # 为每个台站创建下载请求
                for station_info in stations:
                    # 计算时间窗口
                    start_time, end_time, distance_deg = self.get_time_window(
                        event, 
                        station_info['latitude'], 
                        station_info['longitude']
                    )
                    
                    if start_time is None:
                        continue
                        
                    # 创建请求
                    request = {
                        'network': station_info['network'],
                        'station': station_info['station'],
                        'location': station_info['location'],
                        'channel_prefix': station_info['channel_prefix'],
                        'start_time': start_time,
                        'end_time': end_time,
                        'event_params': event_params,
                        'distance_deg': distance_deg,
                        'station_latitude': station_info['latitude'],
                        'station_longitude': station_info['longitude']
                    }
                    
                    all_requests.append(request)
                    
            except Exception as e:
                self.logger.warning(f"处理事件失败: {e}")
                continue
        
        # 批量下载
        self.logger.info(f"开始下载 {len(all_requests)} 个波形请求")
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # 分批提交
            batches = [all_requests[i:i+self.batch_size] 
                      for i in range(0, len(all_requests), self.batch_size)]
            
            futures = [executor.submit(self.download_waveform_batch, batch) 
                      for batch in batches]
            
            # 处理结果
            for future in as_completed(futures):
                try:
                    batch_results = future.result()
                    
                    for result in batch_results:
                        if not result['success']:
                            continue
                            
                        req = result['request']
                        st = result['stream']
                        
                        if len(st) == 0:
                            continue
                            
                        try:
                            # 转换为数组
                            actual_t0, data_arr, _ = sbu.stream_to_array(
                                st,
                                component_order="ZNE"
                            )
                            
                            # 计算理论到时采样点
                            origin_time = UTCDateTime(req['event_params']['source_origin_time'])
                            depth_km = req['event_params']['source_depth_km']
                            
                            travel_times = self.calculate_travel_times(depth_km, req['distance_deg'])
                            
                            sr = st[0].stats.sampling_rate
                            
                            # 构建trace参数
                            trace_params = {
                                "station_network_code": req['network'],
                                "station_code": req['station'],
                                "trace_channel": req['channel_prefix'],
                                "station_location_code": req['location'],
                                "station_latitude_deg": req['station_latitude'],
                                "station_longitude_deg": req['station_longitude'],
                                "trace_sampling_rate_hz": sr,
                                "trace_start_time": str(actual_t0),
                                "station_epicentral_distance_deg": req['distance_deg']
                            }
                            
                            # 添加理论到时
                            if travel_times['P']:
                                p_time = origin_time + travel_times['P']
                                p_sample = int((p_time - actual_t0) * sr)
                                if 0 <= p_sample < len(data_arr[0]):
                                    trace_params["trace_p_arrival_sample"] = p_sample
                                    trace_params["trace_p_status"] = "theoretical"
                                    
                            if travel_times['S']:
                                s_time = origin_time + travel_times['S']
                                s_sample = int((s_time - actual_t0) * sr)
                                if 0 <= s_sample < len(data_arr[0]):
                                    trace_params["trace_s_arrival_sample"] = s_sample
                                    trace_params["trace_s_status"] = "theoretical"
                            
                            # 合并参数并写入
                            full_params = {**req['event_params'], **trace_params}
                            writer.add_trace(full_params, data_arr)
                            
                            self.stats['successful_downloads'] += 1
                            
                        except Exception as e:
                            self.logger.debug(f"处理波形失败: {e}")
                            continue
                            
                except Exception as e:
                    self.logger.warning(f"批处理结果失败: {e}")
                    continue
                    
        self.stats['total_downloads'] += len(all_requests)
    
    def download_year_data(self,
                          year: int = 2024,
                          output_dir: Union[str, Path] = "./auspass_data",
                          min_magnitude: Optional[float] = None,
                          max_magnitude: Optional[float] = None,
                          latitude_range: Optional[Tuple[float, float]] = None,
                          longitude_range: Optional[Tuple[float, float]] = None,
                          split_ratio: float = 0.8,
                          resume_from_day: Optional[int] = None):
        """
        下载指定年份的AusPass数据
        
        参数:
        ----------
        year : int
            年份
        output_dir : str or Path
            输出目录
        min_magnitude : float, optional
            最小震级（None表示不限制）
        max_magnitude : float, optional
            最大震级
        latitude_range : tuple, optional
            纬度范围（默认澳大利亚地区）
        longitude_range : tuple, optional
            经度范围（默认澳大利亚地区）
        split_ratio : float
            训练集比例
        resume_from_day : int, optional
            从第几天开始（用于断点续传）
        """
        
        # 设置输出路径
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True, parents=True)
        
        # 设置时间范围
        start_time = UTCDateTime(f"{year}-01-01T00:00:00")
        end_time = UTCDateTime(f"{year}-12-31T23:59:59")
        
        # 默认澳大利亚地区范围
        if latitude_range is None:
            latitude_range = (-45, -10)  # 澳大利亚纬度范围
        if longitude_range is None:
            longitude_range = (110, 155)  # 澳大利亚经度范围
        
        self.logger.info("="*60)
        self.logger.info(f"开始下载AusPass {year}年地震数据")
        self.logger.info(f"时间范围: {start_time} - {end_time}")
        if min_magnitude:
            self.logger.info(f"最小震级: {min_magnitude}")
        else:
            self.logger.info("震级: 不限制")
        self.logger.info(f"地理范围: 纬度 {latitude_range}, 经度 {longitude_range}")
        self.logger.info(f"输出目录: {output_dir.absolute()}")
        self.logger.info("="*60)
        
        # 准备查询参数
        event_kwargs = {
            "orderby": "time"
        }
        
        if min_magnitude is not None:
            event_kwargs["minmagnitude"] = min_magnitude
        if max_magnitude:
            event_kwargs["maxmagnitude"] = max_magnitude
        if latitude_range:
            event_kwargs["minlatitude"] = latitude_range[0]
            event_kwargs["maxlatitude"] = latitude_range[1]
        if longitude_range:
            event_kwargs["minlongitude"] = longitude_range[0]
            event_kwargs["maxlongitude"] = longitude_range[1]
            
        # 设置数据格式
        data_format = {
            "dimension_order": "CW",
            "component_order": "ZNE", 
            "measurement": "velocity",
            "unit": "counts",
            "instrument_response": "not restituted",
        }
        
        # 创建写入器
        metadata_path = output_dir / f"metadata_auspass_{year}.csv"
        waveforms_path = output_dir / f"waveforms_auspass_{year}.hdf5"
        
        # 保存进度
        progress_path = output_dir / "download_progress.json"
        completed_days = set()
        
        if progress_path.exists() and resume_from_day is None:
            with open(progress_path, 'r') as f:
                progress = json.load(f)
                completed_days = set(progress.get('completed_days', []))
                last_day = progress.get('last_completed_day', 0)
                resume_from_day = last_day + 1
                self.logger.info(f"从进度文件恢复，从第 {resume_from_day} 天继续")
                self.logger.info(f"已完成 {len(completed_days)} 天的下载")
        
        # 计算天数
        total_days = 365 if year % 4 != 0 else 366
        start_day = resume_from_day if resume_from_day else 1
        
        # 按天下载
        with sbd.WaveformDataWriter(metadata_path, waveforms_path) as writer:
            writer.data_format = data_format
            
            for day_of_year in range(start_day, total_days + 1):
                # 跳过已完成的天数
                if day_of_year in completed_days:
                    self.logger.info(f"跳过第 {day_of_year} 天（已完成）")
                    continue
                    
                # 计算当天的日期
                current_date = start_time + (day_of_year - 1) * 86400
                day_start = UTCDateTime(current_date.strftime("%Y-%m-%dT00:00:00"))
                day_end = UTCDateTime(current_date.strftime("%Y-%m-%dT23:59:59"))
                
                self.logger.info(f"\n处理第 {day_of_year}/{total_days} 天: {day_start.strftime('%Y-%m-%d')}")
                
                # 获取当天的事件目录
                client = self.get_client()
                try:
                    catalog = client.get_events(
                        starttime=day_start,
                        endtime=day_end,
                        **event_kwargs
                    )
                    
                    n_events = len(catalog)
                    self.logger.info(f"{day_start.strftime('%Y-%m-%d')} 找到 {n_events} 个事件")
                    self.stats['total_events'] += n_events
                    self.stats['daily_events'][day_start.strftime('%Y-%m-%d')] = n_events
                    
                except Exception as e:
                    self.logger.error(f"获取 {day_start.strftime('%Y-%m-%d')} 事件目录失败: {e}")
                    continue
                finally:
                    self.return_client(client)
                
                if len(catalog) == 0:
                    # 保存进度
                    completed_days.add(day_of_year)
                    with open(progress_path, 'w') as f:
                        json.dump({
                            'last_completed_day': day_of_year,
                            'completed_days': list(completed_days),
                            'stats': self.stats
                        }, f, indent=2)
                    continue
                    
                # 决定训练/验证集分割
                n_train = int(len(catalog) * split_ratio)
                train_events = catalog[:n_train]
                val_events = catalog[n_train:]
                
                # 处理训练集
                if train_events:
                    self.logger.info(f"处理 {len(train_events)} 个训练集事件")
                    event_batches = [train_events[i:i+5] 
                                   for i in range(0, len(train_events), 5)]
                    
                    for batch_idx, batch in enumerate(event_batches):
                        self.logger.info(f"训练集批次 {batch_idx+1}/{len(event_batches)}")
                        self.process_event_batch(batch, writer, split='train')
                        
                # 处理验证集  
                if val_events:
                    self.logger.info(f"处理 {len(val_events)} 个验证集事件")
                    event_batches = [val_events[i:i+5]
                                   for i in range(0, len(val_events), 5)]
                    
                    for batch_idx, batch in enumerate(event_batches):
                        self.logger.info(f"验证集批次 {batch_idx+1}/{len(event_batches)}")
                        self.process_event_batch(batch, writer, split='dev')
                        
                # 输出当日统计
                self.logger.info(f"\n{day_start.strftime('%Y-%m-%d')} 统计:")
                self.logger.info(f"  处理事件: {n_events}")
                self.logger.info(f"  累计成功下载: {self.stats['successful_downloads']}")
                self.logger.info(f"  累计失败下载: {self.stats['failed_downloads']}")
                self.logger.info(f"  缓存命中: {self.stats['cache_hits']}")
                self.logger.info(f"  累计数据量: {self.stats['data_volume_gb']:.2f} GB")
                
                # 保存进度
                completed_days.add(day_of_year)
                with open(progress_path, 'w') as f:
                    json.dump({
                        'last_completed_day': day_of_year,
                        'completed_days': list(completed_days),
                        'stats': self.stats
                    }, f, indent=2)
                
                # 每隔一周清理缓存
                if day_of_year % 7 == 0 and len(self.waveform_cache) > 3000:
                    self.waveform_cache.clear()
                    self.logger.info("清理波形缓存")
                    
        # 最终统计
        self.logger.info("\n" + "="*60)
        self.logger.info("下载完成！")
        self.logger.info(f"总事件数: {self.stats['total_events']}")
        self.logger.info(f"总下载数: {self.stats['total_downloads']}")
        self.logger.info(f"成功下载: {self.stats['successful_downloads']}")
        if self.stats['total_downloads'] > 0:
            success_rate = self.stats['successful_downloads'] / self.stats['total_downloads'] * 100
            self.logger.info(f"成功率: {success_rate:.1f}%")
        self.logger.info(f"总数据量: {self.stats['data_volume_gb']:.2f} GB")
        self.logger.info(f"输出文件:")
        self.logger.info(f"  元数据: {metadata_path}")
        self.logger.info(f"  波形数据: {waveforms_path}")
        
        # 输出每日事件分布
        self.logger.info("\n每日事件分布摘要:")
        daily_counts = list(self.stats['daily_events'].values())
        if daily_counts:
            self.logger.info(f"  平均每日事件: {np.mean(daily_counts):.1f}")
            self.logger.info(f"  最多单日事件: {max(daily_counts)}")
            self.logger.info(f"  最少单日事件: {min(daily_counts)}")
        
        self.logger.info("="*60)
        
        # 删除进度文件
        if progress_path.exists():
            progress_path.unlink()
            
        return self.stats


# 使用示例
if __name__ == "__main__":
    # 创建下载器实例
    harvester = AusPassSeismoHarvester(
        max_workers=8,  # 并发数
        batch_size=30,  # 批处理大小
        log_level="INFO"
    )
    
    # 下载2024年澳大利亚地区所有地震数据（不限制震级）
    stats = harvester.download_year_data(
        year=2024,
        output_dir="./auspass_2024_all",
        min_magnitude=None,  # 不限制最小震级
        max_magnitude=None,  # 不限制最大震级
        latitude_range=(-45, -10),  # 澳大利亚纬度范围
        longitude_range=(110, 155),  # 澳大利亚经度范围
        split_ratio=0.8,  # 80%训练集，20%验证集
        resume_from_day=None  # 从头开始
    )